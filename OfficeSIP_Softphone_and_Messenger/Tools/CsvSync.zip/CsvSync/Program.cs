﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;
using System.Text;
using System.IO;

namespace CsvSync
{
	class Program
	{
		static int Main(string[] args)
		{
			if (args.Length < 3)
			{
				Console.WriteLine("Add and reorder records from all.csv to dst.csv if it exist in src.csv");
				Console.WriteLine("Usage: CsvSync all.csv src.csv dst.csv");
			}

			Console.WriteLine("{0} -> {1} -> {2}", args[0], args[1], args[2]);

			var all = ReadCsvFile(args[0]);
			var src = ReadCsvFile(args[1]);
			var dst = File.Exists(args[2]) ? ReadCsvFile(args[2]) : new List<string[]>();

			var result = new List<string[]>(src.Count);

			foreach (var item in src)
			{
				//if (item[1] == "msg1:System.String.$Content")
				//    Console.WriteLine(item[6]);

				int allIdx = Find(all, item);
				if (allIdx < 0)
				{
					Console.WriteLine("Error: src item not found in all - {0},{1}", item[0], item[1]);
					return -1;
				}

				int dstIdx = Find(dst, item);
				if (dstIdx < 0)
					result.Add(all[allIdx]);
				else
					result.Add(dst[dstIdx]);
			}

			using (TextWriter writer = new StreamWriter(new FileStream(args[2], FileMode.Create)))
			{
				foreach (var item in result)
				{
					var value = item[6];
					if (value.IndexOfAny(new[] { ',', '\r', '\n', }) >= 0)
						value = '"' + value + '"';
					writer.WriteLine("{0},{1},{2},{3},{4},{5},{6}", item[0], item[1], item[2], item[3], item[4], item[5], value);
				}
			}

			return 0;
		}

		static int Find(List<string[]> list, string[] item)
		{
			for (int i = 0; i < list.Count; i++)
				if (list[i][0] == item[0] && list[i][1] == item[1])
					return i;
			return -1;
		}

		static List<string[]> ReadCsvFile(string filename)
		{
			var list = new List<string[]>();

			using (var reader = new TextFieldParser(filename))
			{
				reader.TextFieldType = FieldType.Delimited;
				reader.SetDelimiters(",");

				try
				{
					while (reader.EndOfData == false)
					{
						list.Add(reader.ReadFields());
					}
				}
				catch (MalformedLineException ex)
				{
					Console.WriteLine("Line " + ex.Message + "is not valid and will be skipped.");
				}
			}

			return list;
		}
	}
}
